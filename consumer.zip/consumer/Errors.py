
class UnknownClientMethod(Exception):
    pass

class BucketNotFound(Exception):
    pass
